document.getElementById("formakun").addEventListener("submit", function (e) {
  e.preventDefault();

  const formData = new FormData(this);

  fetch(base_url + "auth/signup", {
    method: "POST",
    body: formData,
  })
    .then(res => res.json())
    .then(data => {
      if (data.status === "success") {
        alert("Akun berhasil dibuat!");
        this.reset();
        const modal = bootstrap.Modal.getInstance(document.getElementById('signUpModal'));
        modal.hide();
      } else {
        alert(data.message);
      }
    })
    .catch(err => alert("Error: " + err));
});
