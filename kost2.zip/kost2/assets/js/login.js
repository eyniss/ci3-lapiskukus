document.addEventListener("DOMContentLoaded", function () {
  const form = document.getElementById("formlogin");
  if (!form) return;

  form.addEventListener("submit", function (e) {
    e.preventDefault();

    const formData = new FormData(this);

    // Ganti ini sesuai base_url yang dikirim dari view
    const loginUrl = window.base_url + "auth/login";

    fetch(loginUrl, {
      method: "POST",
      body: formData
    })
    .then(res => res.json())
    .then(data => {
      if (data.status === "success") {
        alert("Login berhasil!");
        form.reset();
        const modalElement = document.getElementById('loginModal');
        const modal = bootstrap.Modal.getInstance(modalElement);
        if (modal) modal.hide();
        window.location.href = data.redirect || (window.base_url + "home");
      } else {
        alert("Error: " + data.message);
      }
    })
    .catch(err => {
      console.error(err);
      alert("Terjadi kesalahan pada AJAX: " + err);
    });
  });
});

