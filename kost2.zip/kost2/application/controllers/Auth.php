<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * @property User_model $User_model
 * @property CI_Input $input
 * @property CI_Session $session
 **/

class Auth extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('User_model');
        $this->load->library('session');
    }

    // Fungsi registrasi
    public function signup() {
        $name = $this->input->post('name', TRUE);
        $email = $this->input->post('emailaddress', TRUE);
        $password = $this->input->post('password', TRUE);
        $confirm = $this->input->post('confirm_password', TRUE);

        if ($password !== $confirm) {
            echo json_encode(['status' => 'error', 'message' => 'Password tidak cocok.']);
            return;
        }

        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        $result = $this->User_model->register($name, $email, $hashed_password);
        echo json_encode($result);
    }

    // Fungsi login
    public function login() {
        $email = $this->input->post('login_email');
        $password = $this->input->post('login_password');

        $user = $this->User_model->login($email, $password);

        if ($user) {
            $this->session->set_userdata('user_id', $user->id);
            echo json_encode(['status' => 'success', 'redirect' => site_url('dashboard')]);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Email atau password salah!']);
        }
    }
    public function logout(){
    $this->session->unset_userdata('user_id');
    $this->session->unset_userdata('user_name');
    $this->session->sess_destroy(); // opsional, untuk menghapus semua session
    redirect(base_url()); // arahkan ke halaman utama setelah logout
    }

}
