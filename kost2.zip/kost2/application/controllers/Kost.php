<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Kost extends CI_Controller {

    public function detail($id = 0)
    {
        $kosts = [
            [
                'nama' => 'Omah Kost Tipe A',
                'lokasi' => 'Kediri',
                'harga' => 'Rp 350.000',
                
                'tersisa' => 2,
                'transaksi' => 22,
                'spesifikasi' => '3 x 2.5 meter',
                'listrik' => true,
                'fasilitas_kamar' => ['Kasur Single Bed', 'Bantal', 'Meja', 'Kursi', 'Lemari Baju', 'Ventilasi', 'Kamar Mandi Luar'],
                'fasilitas_umum' => ['WiFi', 'Penjaga Kos', 'Taman', 'Parkir Motor', 'Ruang Tamu', 'Dapur', 'Dispenser', 'Jemuran'],
                'peraturan' => ['Akses 24 Jam', 'Dilarang merokok di kamar', 'Lawan jenis dilarang ke kamar', 'Kamar hanya bagi penyewa'],
            ],
            [
                'nama' => 'Omah Kost Tipe B',
                'lokasi' => 'Kediri',
                'harga' => 'Rp 350.000',
                'tersisa' => 1,
                'transaksi' => 10,
                'spesifikasi' => '3.5 x 3 meter',
                'listrik' => false,
                'fasilitas_kamar' => ['Kasur Queen Bed', 'Meja Belajar', 'Kipas Angin', 'Lemari Pakaian', 'Kamar Mandi Dalam'],
                'fasilitas_umum' => ['WiFi', 'Parkir Motor', 'Ruang Cuci', 'Dapur', 'Jemuran'],
                'peraturan' => ['Akses 24 Jam', 'Tidak boleh bawa hewan', 'Dilarang keras merokok di kamar'],
            ],
            [
                'nama' => 'Omah Kost Tipe C',
                'lokasi' => 'Malang',
                'harga' => 'Rp 550.000',
                'tersisa' => 3,
                'pengelola' => 'Dina',
                'transaksi' => 18,
                'spesifikasi' => '4 x 3 meter',
                'listrik' => true,
                'fasilitas_kamar' => ['Kasur King Size', 'Meja', 'Kursi', 'Lemari Besar', 'Kamar Mandi Dalam', 'AC'],
                'fasilitas_umum' => ['WiFi', 'Parkir Mobil', 'Dapur Bersih', 'Ruang Tamu', 'Laundry', 'CCTV'],
                'peraturan' => ['Tidak boleh bawa hewan peliharaan', 'Dilarang membawa tamu menginap', 'Akses 24 jam dengan kartu'],
            ],            
        ];
    
        if (!isset($kosts[$id])) {
            show_404();
        }
    
        $data['kost'] = $kosts[$id];
        $this->load->view('kost/detail', $data);
    }
}
