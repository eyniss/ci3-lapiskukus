 <!-- <?php

// session_start();
// include 'konek.php'; // koneksi database

// // Koneksi ke database
// $host = "localhost";
// $user = "root";
// $pass = "";
// $dbname = "kost";

// // session_start();
// $conn = new mysqli($host, $user, $pass, $dbname);
// if ($conn->connect_error) {+
//     die("Koneksi gagal: " . $conn->connect_error);
// }
// if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ajax'])) {
//   header('Content-Type: application/json');
//   $email = $_POST['login_email'];
//   $password = $_POST['login_password'];

//   $stmt = $conn->prepare("SELECT * FROM users WHERE emailaddress = ?");
//   $stmt->bind_param("s", $email);
//   $stmt->execute();
//   $result = $stmt->get_result();
//   $user = $result->fetch_assoc();

//   if ($user && password_verify($password, $user['password'])) {
//       $_SESSION['user'] = $user;

//       // ✅ Tambahkan pencatatan ke tabel login di sini
//       $login_time = date('Y-m-d H:i:s');
//       $ip_address = $_SERVER['REMOTE_ADDR'];
//       $user_id = $user['id']; // Pastikan kolom `id` ada di tabel `users`

//       mysqli_query($conn, "INSERT INTO login (id, login_time, ip_address) VALUES ('$user_id', '$login_time', '$ip_address')");

//       echo json_encode(["status" => "success"]);
//   } else {
//       echo json_encode(["status" => "error", "message" => "Email atau password salah!"]);
//   }
//   exit();
// } 
// ?> 

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="home.html" rel="stylesheet">
</head>
<body> -->
<script>
  const base_url = "<?= base_url() ?>";
</script>
 
<div class="modal fade" id="loginModal" tabindex="-1" aria-labelledby="loginModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <form id="formlogin" method="POST">
        <div class="modal-header">
          <h5 class="modal-title" id="loginModalLabel">Login</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <div class="mb-3">
            <label for="loginEmail" class="form-label">Email</label>
            <input type="email" class="form-control" id="loginEmail" name="login_email" placeholder="Enter your email" required>
          </div>
          <div class="mb-3">
            <label for="loginPassword" class="form-label">Password</label>
            <input type="password" class="form-control" id="loginPassword" name="login_password" placeholder="Enter your password" required>
          </div>
        </div>
        <div class="modal-footer">
          <button type="submit" class="btn btn-primary">Login</button>
        </div>
      </form>
    </div>
  </div>
</div>


<?php if (isset($login_error)): ?>
  <div class="alert alert-danger">
    <?= $login_error ?>
  </div>
<?php endif; ?>



<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<!-- 
</body>
</html> -->
