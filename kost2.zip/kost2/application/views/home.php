

  
<main>

<section>	
  <div class="outlet-content">
  <div id="carouselExampleCaptions" class="carousel slide">
      <div class="carousel-inner">
        <div class="carousel-item active">
        <img src="<?= base_url('assets/img/banner0.png') ?>" alt="banner" class="d-block w-100">
          <div class="carousel-caption d-none d-md-block">
            <h5>Selamat Datang di Omah Kost</h5>
            <p>Hunian Nyaman & Strategis untuk Hidup Lebih Praktis! <br> Kost lengkap, aman, dan tenang di lokasi paling ideal.</p>
          </div>
        </div>
        <div class="carousel-item">
          <img src="<?= base_url('assets/img/bannerr2.png') ?>" class="d-block w-100" alt="banner">
          <div class="carousel-caption d-none d-md-block">
            <h5>"Cari Kost?"</h5>
            <p>Temukan Kenyamanan Disini Seperti di Rumah Sendiri!.</p>
          </div>
        </div>
        <div class="carousel-item">
          <img src="<?= base_url('assets/img/bannerr3.png') ?>" class="d-block w-100" alt="banner">
          <div class="carousel-caption d-none d-md-block">
            <h5>"Ngekost Rasa Rumah Sendiri!"</h5>
            <p> Nyaman, bersih, dan fasilitas lengkap. Yuk, pindah ke OmahKost!</p>
          </div>
        </div>
      </div>
      <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Previous</span>
      </button>
      <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Next</span>
      </button>
    </div>

      <!-- <div class="carousel-indicators">
        <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
        <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1" aria-label="Slide 2"></button>
        <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2" aria-label="Slide 3"></button>
      </div> -->

    <!-- <div class="text-left">
      <h1>Tempat Terbaik Membawa Pulang Oleh-oleh<br> Kebanggaan Kota Malang</h1>
      <p>Dari kelembutan setiap lapisan, hingga rasa yang khas,<br>
        kami hadir untuk menemani momen manismu bersama orang tersayang.</p>
    </div> -->
  </div>
</section>

<section class="slide2">
<h2 class="text-center text-light fw-bold">Keuntungan Tinggal Di Omah Kost</h2>

<div class="d-flex flex-row gap-4 p-5">


<!-- Card 1 -->
<div class="card">
  <div class="card-img-wrapper">
  <img src="<?= base_url('assets/img/card1.png') ?>" class="card-img-top" alt="foto teras">
  </div>
<div class="card-body">
<h5 class="card-title">Card 2</h5>
<p class="card-text">mudah ditemukan dan dekat dengan berbagai fasilitas umum seperti kampus,<br> pusat perbelanjaan, dan transportasi umum. </p>
</div>
</div>

 

<!-- Card 2-->
<div class="card">
<img src="<?= base_url('assets/img/cardd2.png') ?>"  class="card-img-top" alt="...">
<div class="card-body">
<h5 class="card-title">Card 3</h5>
<p class="card-text">Area halaman yang luas memberikan suasana asri dan lapang, cocok untuk <br>bersantai atau aktivitas outdoor ringan.</p>

</div>
</div>

<!-- Card 3 -->
<div class="card">
<img src="<?= base_url('assets/img/cardd3.jpeg') ?>" class="card-img-top" alt="...">
<div class="card-body">
<h5 class="card-title">Card 3</h5>
<p class="card-text">Dilengkapi ruang tamu bersama yang nyaman untuk menerima tamu atau <br>berkumpul. </p>

</div>
</div>

<!-- Card4-->
<div class="card">
<img src="<?= base_url('assets/img/card4.png') ?>" class="card-img-top" alt="...">
<div class="card-body">
<h5 class="card-title">Card 3</h5>
<p class="card-text">Biaya sewa sangat terjangkau, ideal untuk yang mencari hunian nyaman <br>di lokasi terbaik</p>

</div>
</div>
</div>

<!-- Card 3
<div class="card">
<img src="assets/img/card3.jpg" class="card-img-top" alt="...">
<div class="card-body">
<h5 class="card-title">Card 3</h5>
<p class="card-text">Biaya sewa sangat terjangkau, ideal untuk mahasiswa, pasangan muda, atau pekerja yang mencari hunian nyaman di lokasi terbaik.</p>
<a href="#" class="btn btn-primary">Detail</a>
</div>
</div>
</div> -->
</section>


<div class="kost-container">
<div class="shadow-sm rounded p-5 custom-bg">
    <h4 class="mb-4 text-center">Daftar Kost Populer</h4>
    <div class="d-flex gap-3 justify-content-center">

  <?php
    $kosts = [
      [
        'nama' => 'Omah Kost Tipe A',
        'tipe' => 'Putra/Putri',
        'lokasi' => 'Kediri',
        'fasilitas' => ['K. Mandi Dalam', 'WiFi', 'Kloset Duduk', 'Kasur'],
        'harga_asli' => 'Rp400.000',
        'harga' => 'Rp350.000',
        'sisa' => 0,
        'gambar' => 'http://localhost/kost2/assets/img/typea.png'
      ],
      [
        'nama' => 'Omah Kost Tipe B',
        'tipe' => 'Putra/Putri',
        'lokasi' => 'Kediri',
        'fasilitas' => ['K. Mandi Dalam', 'WiFi', 'Kloset Duduk', 'Kasur'],
        'harga_asli' => 'Rp400.000',
        'harga' => 'Rp350.000',
        'sisa' => 2,
        'gambar' => 'http://localhost/kost2/assets/img/typeb.png'
      ],
      [
        'nama' => 'Omah Kost Tipe C',
        'tipe' => 'Putra',
        'lokasi' => 'Malang',
        'fasilitas' => ['K. Mandi Luar', 'WiFi', 'Kloset Duduk', 'Kasur'],
        'harga_asli' => 'Rp550.000',
        'harga' => 'Rp500.000',
        'sisa' => 1,
        'gambar' => 'http://localhost/kost2/assets/img/typec.png'
      ],
    ];

    foreach ($kosts as $index => $kost): ?>
      <div class="kost-card">
        <?php if ($kost['sisa'] > 0): ?>
          <div class="badge-sisa">Sisa <?= $kost['sisa'] ?> kamar</div>
        <?php endif; ?>
        <img src="<?= $kost['gambar'] ?>" alt="<?= $kost['nama'] ?>">
        <div class="kost-body">
          <small><?= $kost['tipe'] ?></small>
          <h5><?= $kost['nama'] ?></h5>
          <div class="lokasi"><?= $kost['lokasi'] ?></div>
          <div class="harga-asli"><?= $kost['harga_asli'] ?></div>
          <div class="harga-diskon"><?= $kost['harga'] ?> /bulan</div>
          <?php foreach ($kost['fasilitas'] as $fasilitas): ?>
            <span class="label-fasilitas"><?= $fasilitas ?></span>
          <?php endforeach; ?>
          <a href="<?= site_url('kost/detail/' . $index) ?>" class="btn-detail">Lihat Fasilitas</a>
        </div>
      </div>
  <?php endforeach; ?>
</div>
</div>
</div>

<section class="banner2">
<div class="container-fluid">
<div class="row align-items-center">
  
  <!-- Gambar -->
  <div class="col-md-6 p-0">
    <img src="<?= base_url('assets/img/baner5.png') ?>" class="img-fluid banner-img" alt="Banner Image">
  </div>

  <!-- Konten Teks -->
  <div class="col-md-6 d-flex flex-column justify-content-center align-items-start banner-text">
        <h2 class="mb-4 text-white"><span style="color: #005F5F;">Masih Bingung Cari Tempat Kost?</span><br>Yuk cari Hunian<br>untukmu sekarang di Omah Kost!</h2>
        <a href="#" class="btn btn-light rounded-3 px-4 py-2">Cari Sekarang</a>

    <!-- Indikator Bulat -->
    <div class="indicator-circle"></div>
  </div>

</div>
</div>
</section>


<script>
  const base_url = "<?= base_url() ?>";
</script>
 
<div class="modal fade" id="loginModal" tabindex="-1" aria-labelledby="loginModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <form id="formlogin" method="POST">
        <div class="modal-header">
          <h5 class="modal-title" id="loginModalLabel">Login</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <div class="mb-3">
            <label for="loginEmail" class="form-label">Email</label>
            <input type="email" class="form-control" id="loginEmail" name="login_email" placeholder="Enter your email" required>
          </div>
          <div class="mb-3">
            <label for="loginPassword" class="form-label">Password</label>
            <input type="password" class="form-control" id="loginPassword" name="login_password" placeholder="Enter your password" required>
          </div>
        </div>
        <div class="modal-footer">
          <button type="submit" class="btn btn-success">Login</button>
        </div>
      </form>
    </div>
  </div>
</div>


<?php if (isset($login_error)): ?>
  <div class="alert alert-danger">
    <?= $login_error ?>
  </div>
<?php endif; ?>

<!-- Sign Up Modal -->
<div class="modal fade" id="signUpModal" tabindex="-1" aria-labelledby="signUpModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <form id="formakun" method="post" action="<?= site_url('auth/signup') ?>">
        <div class="modal-header">
          <h5 class="modal-title" id="signUpModalLabel">Create an Account</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <div class="mb-3">
            <label for="signupName" class="form-label">Name</label>
            <input type="text" class="form-control" id="signupName" placeholder="Enter your name" name="name" required>
          </div>
          <div class="mb-3">
            <label for="signupEmail" class="form-label">Email address</label>
            <input type="email" class="form-control" id="signupEmail" placeholder="Enter your email" name="emailaddress" required>
          </div>
          <div class="mb-3">
            <label for="signupPassword" class="form-label">Password</label>
            <input type="password" class="form-control" id="signupPassword" placeholder="Enter your password" name="password" required>
          </div>
          <div class="mb-3">
            <label for="signupConfirmPassword" class="form-label">Confirm Password</label>
            <input type="password" class="form-control" id="signupConfirmPassword" placeholder="Confirm your password" name="confirm_password" required>
          </div>
        </div>
        <div class="modal-footer">
          <button type="submit" class="btn btn-success w-100">Sign Up</button>
        </div>
      </form>
    </div>
  </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<script src="<?= base_url('assets/js/login.js'); ?>"></script>

<script src="<?= base_url('assets/js/signup.js'); ?>"></script>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</main>
<!-- 
<script>
  window.base_url = "<?= base_url(); ?>";
  <link rel="stylesheet" href="<?= base_url('assets/css/style.css') ?>">
</script> -->
