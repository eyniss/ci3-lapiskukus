<footer class="footer">
        <div class="container">
          <div class="footer-top">
            <div class="footer-brand">
              <img src="<?= base_url('assets/img/logoo.png') ?>" alt="Logo OmahKost" class="logo">             
            </div>
      
            <div class="footer-links">
              <div>
                <h4>Tenant</h4>
                <ul>
                  <li>Kost</li>
                  <li>Apartemen</li>
                  <li>Community</li>
                </ul>
              </div>
    
              <div>
                <h4>OmahKost For Business</h4>
                <ul>
                  <li>Corporate Housing</li>
                  <li>Corporate Subscription</li>
                  <li>RuCollab</li>
                </ul>
              </div>
              <div>
                <h4>Resource</h4>
                <ul>
                  <li>Tentang omahKost</li>
                  <li>FAQ</li>
                  <li>Karir</li>
                  <li>Stories</li>
                </ul>
              </div>
              <div class="footer-support">
                <h4>Support</h4>
                <ul>
                  <li>📞 +62 811-154-6477</li>
                  <li>✉️ info@omahKost.co</li>
                </ul>
                <p>Jam Operasional</p>
                <p>Senin - Jumat: 10.00 - 19.00<br>Sabtu - Minggu: 10.30 - 17.00</p>
              </div>
            </div>
          </div>
      
          <div class="footer-bottom">
            <p>© 2025 OmahKost. All rights reserved. <a href="#">Syarat & Ketentuan</a> | <a href="#">Kebijakan Privasi</a></p>
          
          </div>
        </div>
      </footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script> 

<script>
  window.addEventListener('scroll', function() {
    var navbar = document.getElementById('navbar');
    if (window.scrollY > 50) {
      navbar.classList.add('scrolled');
    } else {
      navbar.classList.remove('scrolled');
    }
  });
</script>

</body> </html>