<!-- White Navbar with Shadow  -->

<nav class="navbar navbar-expand-lg navbar-light bg-white navbar-shadow ">
  <div class="container-fluid">
    <header class="sticky-header">
      <div class="logo-title">
        <img src="<?= base_url('assets/img/logoo.png') ?>" alt="Logo" class="logo">
      </div>
    </header>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarMain" aria-controls="navbarMain" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarMain">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item"><a class="nav-link" href="#">Home</a></li>
        <li class="nav-item"><a class="nav-link" href="#">Pricing</a></li>
        <li class="nav-item"><a class="nav-link" href="#">FAQs</a></li>
        <li class="nav-item"><a class="nav-link" href="#">About Us</a></li>
      </ul>
      <div class="d-flex">
      <?php if ($this->session->userdata('user_name')): ?> 
        <a href="#" class="btn btn-outline-dark me-2"> Hai, <?= $this->session->userdata('user_name'); ?> </a>
         <a href="<?= base_url('logout'); ?>" class="btn btn-outline-danger">Logout</a>
          <?php else: ?> 
          <button type="button" class="btn btn-outline-success me-2" data-bs-toggle="modal" data-bs-target="#loginModal">Login</button>
           <button type="button" class="btn btn-primary btn-success" data-bs-toggle="modal" data-bs-target="#signUpModal">Sign Up</button> 
           <?php endif; ?>
      </div>
    </div>
  </div>
</nav>